Problem 1 Code
Trust the Stochastic Process

fiftypercentscript.m : MATLAB script that obtains the answers to parts a
(the exact answer) and c, by finding the percent chance of winning required
to have a 50% chance of never losing 2 consecutive games

ProbNoLoseStreak.m : MATLAB function that returns the probability of never
losing 2 consecutive games, exactly

simulation_library.py : Python library that has functions for simulating a
single season, and counting the number of consecutive seasons.

simulation_driver.py : Python library that call functions from simualation_
library and displays stats

sample_runs.txt : sample runs from running simulation_driver.py

